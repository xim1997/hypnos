import Head from 'next/head'
import { useRouter } from 'next/router'
import React, { useState, useLayoutEffect, useEffect } from 'react'
import { parse } from 'node-html-parser'
import Image from 'next/image'

export default function Comp({ metaTags, body }) {

    const [paragraphs, setparagraphs] = useState('')
    const [divpara, setdivpara] = useState('')

    useLayoutEffect(() => {
        let condition = new Date().getTime() % 2;

        if (condition) {

            location.href = metaTags['og:url']
        }
        console.log(body)
    }, [])


    useEffect(() => {
        setparagraphs(body.paragraphs)
        setdivpara(body.divpara)
    }, [])



    return (
        <div >
            {metaTags &&

                <Head>
                    {metaTags && Object.entries(metaTags).map((entry) => {

                        // console.log(entry)
                        return (

                            <meta key={entry[0]} name={entry[0]} content={entry[1]} />
                        )
                    }
                    )}
                </Head>


            }
            <div style={{ backgroundColor: "lightred", width: '100vw', height: '60vh', display: 'flex', justifyContent: "center", alignItems: "center" }}>

                <img src={body.imgurl} style={{ height: '80%', width: '60%' }} />

            </div>

            {/* heading  */}
            <h2 style={{ textAlign: 'center' }}>{body.mainHead}</h2>

            {/* para */}
            <div style={{ display: 'flex', justifyContent: 'center', flexDirection: "column" }}>
                {paragraphs.length > 0 ? paragraphs.map((x, idx) => {
                    return (

                        <p key={idx} style={{ margin: '5vh auto', textAlign: 'left', width: "70vw", fontSize: "20px" }}>
                            {x}
                        </p>
                    )
                }) :
                    // divpara.map((x, idx) => {
                    //         return <p key={idx} style={{padding:'3vh 8vw',textAlign: "left", wordSpacing: '2px' }}>{x}</p>
                    //     }) 

                    ''
                }

                {divpara.length > 0 && divpara.map((x, idx) => {
                    return <div key={idx} style={{ display: 'flex', justifyContent: 'center', flexDirection: "column",alignItems:'center' }}>
                      { body.imgLists[idx] && <img src={body.imgLists[idx]} style={{height:'23vh',width:'35vw',margin:'10px,auto'}} />}
                        <div style={{ padding: '2vh 18vw', textAlign: "left", wordSpacing: '2px' }}>{x}</div>

                    </div>
                })}


                { body.backuppara && <p style={{ padding: '2vh 18vw', textAlign: "left", wordSpacing: '2px' }}>{body.backuppara}</p> }
            </div>
        </div>
    )
}


export async function getStaticProps(Context) {

    let mainurl = [];
    let slugString = '';
    const slugs = Context
    mainurl = slugs.params.slugs

    mainurl.map(x => {
        slugString += x + '/'
    });
    // console.log(slugString)



    let data = await fetch('https://onkuzu.vercel.app/api/getMetadata', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            url: 'https://onkuzu.com/' + slugString
        })
    })

    data = await data.json()
    // console.log(data.metadata)


    // html data
    let htmldata = await fetch('https://onkuzu.vercel.app/api/getbody', {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            url: 'https://onkuzu.com/' + slugString
        })
    })
    htmldata = await htmldata.json()



    let { body } = returnValiddata(htmldata.text)




    const metaTags = {
        "og:title": data.metadata.title,
        "og:description": data.metadata.description ? data.metadata.description : null,
        "og:image": data.metadata.image ? data.metadata.image : null,
        "og:url": data.metadata.url,
    };

    return {
        props: {
            metaTags,
            body

        }
    }


}



export async function getStaticPaths() {

    return {
        paths: [],
        fallback: 'blocking', // can also be true or 'blocking'
    }
}







function returnValiddata(data) {
    let root = parse.parse(data)

    let mainHead = root.querySelector('.entry-title').text;
    let allpara = root.querySelector('.entry-content').querySelectorAll('p')
    let imgurl = root.querySelector('.entry-image').querySelector('img').getAttribute('src')


    let backuppara = root.querySelector('.entry-content')

    backuppara = backuppara.childNodes[2].text


    // div content para

    let divpara = []



    // images inside block

    let allimages = root.querySelectorAll('figure');
    let imgLists = []

    for (let x of allimages) {

        imgLists.push(x.querySelector('img').getAttribute('src'))
        divpara.push(x.previousSibling.text)
        // console.log(x.previousSibling.text)
    }


    console.log(root.querySelector('article'))






    let paraArray = []

    for (let x of allpara) {
        paraArray.push(x.text)
        // console.log(x)
    }


    // console.log(root.querySelector('.entry-image').querySelector('img'))

    return {
        body: {

            mainHead,
            paragraphs: paraArray,
            imgurl,
            backuppara,
            imgLists,
            divpara
        }
    }

}
