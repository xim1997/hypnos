
export default async function handler(req, res) {


   
    if (req.method == 'POST') {


        let url = req.body.url;
        const response = await fetch(url);
        const html = await response.text();

        // console.log(html)
        res.json({ text: html })




    }


}